## Packages
framer-motion | For smooth page transitions and micro-interactions
date-fns | For formatting dates

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
