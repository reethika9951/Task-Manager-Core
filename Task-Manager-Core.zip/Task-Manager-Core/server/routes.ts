import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { hashPassword } from "./auth";
import { insertUserSchema, insertTaskSchema } from "@shared/schema";
import passport from "passport";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  setupAuth(app);

  // Auth Routes
  app.post(api.auth.register.path, async (req, res, next) => {
    try {
      const { username, password } = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByUsername(username);
      
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      const hashedPassword = await hashPassword(password);
      const user = await storage.createUser({ username, password: hashedPassword });
      
      req.login(user, (err) => {
        if (err) return next(err);
        res.status(201).json(user);
      });
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message });
      } else {
        next(err);
      }
    }
  });

  app.post(api.auth.login.path, (req, res, next) => {
    // Basic schema check
    try {
      insertUserSchema.parse(req.body);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
    }
    next();
  }, (req, res, next) => {
    // Passport authentication
    passport.authenticate("local", (err: any, user: any, info: any) => {
      if (err) return next(err);
      if (!user) return res.status(401).json({ message: "Invalid credentials" });
      req.login(user, (err) => {
        if (err) return next(err);
        res.status(200).json(user);
      });
    })(req, res, next);
  });

  app.post(api.auth.logout.path, (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  app.get(api.auth.me.path, (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }
    res.json(req.user);
  });

  // Task Routes
  // Middleware to ensure authentication
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    next();
  };

  app.get(api.tasks.list.path, requireAuth, async (req, res) => {
    // In a real app we'd filter by user, but storage.getTasks returns all
    // Let's assume we update storage to filter by user or filter here
    const tasks = await storage.getTasks();
    // Filter by user in memory for now as getTasks fetches all
    const userTasks = tasks.filter(t => t.userId === (req.user as any).id);
    res.json(userTasks);
  });

  app.post(api.tasks.create.path, requireAuth, async (req, res) => {
    try {
      const input = insertTaskSchema.parse(req.body);
      const task = await storage.createTask({
        ...input,
        userId: (req.user as any).id
      });
      res.status(201).json(task);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message });
      } else {
        res.status(500).json({ message: "Internal Server Error" });
      }
    }
  });

  app.get(api.tasks.get.path, requireAuth, async (req, res) => {
    const task = await storage.getTask(Number(req.params.id));
    if (!task) return res.sendStatus(404);
    if (task.userId !== (req.user as any).id) return res.sendStatus(401);
    res.json(task);
  });

  app.patch(api.tasks.update.path, requireAuth, async (req, res) => {
    try {
      const id = Number(req.params.id);
      const existingTask = await storage.getTask(id);
      if (!existingTask) return res.sendStatus(404);
      if (existingTask.userId !== (req.user as any).id) return res.sendStatus(401);

      const input = insertTaskSchema.partial().parse(req.body);
      const updatedTask = await storage.updateTask(id, input);
      res.json(updatedTask);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message });
      } else {
        res.status(500).json({ message: "Internal Server Error" });
      }
    }
  });

  app.delete(api.tasks.delete.path, requireAuth, async (req, res) => {
    const id = Number(req.params.id);
    const existingTask = await storage.getTask(id);
    if (!existingTask) return res.sendStatus(404);
    if (existingTask.userId !== (req.user as any).id) return res.sendStatus(401);

    await storage.deleteTask(id);
    res.sendStatus(200);
  });

  return httpServer;
}
